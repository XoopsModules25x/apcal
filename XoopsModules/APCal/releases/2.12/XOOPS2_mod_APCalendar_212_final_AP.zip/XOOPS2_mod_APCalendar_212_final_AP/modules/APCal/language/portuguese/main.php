<?php

if( defined( 'FOR_XOOPS_LANG_CHECKER' ) || ! defined( 'APCAL_MB_LOADED' ) ) {

define( 'APCAL_MB_LOADED' , 1 ) ;

// index.php
define('_MB_APCAL_ERR_NOPERMTOUPDATE',"Voc� n�� tem permiss�� para mudar eventos");
define('_APCAL_APURL', 'http://xoops.antiquespromotion.ca');
define('_APCAL_APURL2', 'http://www.antiquespromotion.ca');
define('APCAL_COPYRIGHT' , '<a href="http://xoops.antiquespromotion.ca" title="Calendar for Xoops" target="_blank">APCal</a> by <a href="http://www.antiquespromotion.ca" title="Antiques Promotion Canada" target="_blank">AP</a>');
define('_MB_APCAL_ERR_NOPERMTOINSERT',"Voc� n�� tem permiss�� para criar eventos");
define('_MB_APCAL_ERR_NOPERMTODELETE',"Voc� n�� tem permiss�� para excluir eventos");
define('_MB_APCAL_ALT_PRINTTHISEVENT',"Imprimir este evento");

// print.php
define('_MB_APCAL_COMESFROM',"Este evento v�� de %s");
define('_MB_APCAL_PARMALINK',"O site deste evento");


}

?>