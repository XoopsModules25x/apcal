<?php

if( defined( 'FOR_XOOPS_LANG_CHECKER' ) || ! defined( 'APCAL_MB_LOADED' ) ) {

define( 'APCAL_MB_LOADED' , 1 ) ;

// index.php
define('_MB_APCAL_ERR_NOPERMTOUPDATE',"您沒有編輯的權限！");
define('_APCAL_APURL', 'http://xoops.antiquespromotion.ca');
define('_APCAL_APURL2', 'http://www.antiquespromotion.ca');
define('APCAL_COPYRIGHT' , '<a href="http://xoops.antiquespromotion.ca" title="Calendar for Xoops" target="_blank">APCal</a> by <a href="http://www.antiquespromotion.ca" title="Antiques Promotion Canada" target="_blank">AP</a>');
define('_MB_APCAL_ERR_NOPERMTOINSERT',"您沒有發表的權限！");
define('_MB_APCAL_ERR_NOPERMTODELETE',"您沒有刪除的權限！");
define('_MB_APCAL_ALT_PRINTTHISEVENT',"列印模式");

// print.php
define('_MB_APCAL_COMESFROM',"這個事件是由 %s 所發表的事件。");

}

?>