composite +dither -compose over $1.png apcal_slogo.gif apcal$1_slogo.gif
