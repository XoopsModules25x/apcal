<?php

if( defined( 'FOR_XOOPS_LANG_CHECKER' ) || ! defined( 'APCAL_BL_LOADED' ) ) {



// Appended by Xoops Language Checker -GIJOE- in 2005-04-22 12:02:02
define('_MB_APCAL_MAXGIFSADAY','Max antal dotgifs per dag');
define('_MB_APCAL_JUSTONCEADAYAPLUGIN','Visa endast 1 gif-bild per dag och per plugin');
define('_MB_APCAL_PLUGINS','Aktiva Plugin');
define('_MB_APCAL_PLUGINS_DESC','lista plugin\'s namnet separerad med , (komma)');
define('_MB_APCAL_PLUGINS_VALID','Giltiga Plugin moduler');

// Appended by Xoops Language Checker -GIJOE- in 2005-01-08 04:36:50
define('_MB_APCAL_MAXITEMS','Visa');
define('_MB_APCAL_CATSEL','Kategori');
define('_MB_APCAL_CATSELSUB','Visa ocks� underkategorier');
define('_MB_APCAL_UNTILDAYS','Antal %s dagar (0 betyder o��dligt)');

define( 'APCAL_BL_LOADED' , 1 ) ;

// for monthly calendar block
define('_MB_APCAL_PREV_MONTH','F��ra');
define('_MB_APCAL_NEXT_MONTH','N��ta');
define('_MB_APCAL_YEAR','��r');
define('_MB_APCAL_MONTH','M��ad');
define('_MB_APCAL_JUMP','G� till');

// for after the day's events block
// %s means the indicated day
define('_MB_APCAL_EVENTS_AFTER','H��delser efter %s');

// for the day's events block
// %s means the indicated day
define('_MB_APCAL_EVENTS_THEDAY','H��delser den %s');



// Appended by Xoops Language Checker -GIJOE- in 2004-01-14 18:31:01
define('_MB_APCAL_MAXNEWITEMS','Visa');

}

?>