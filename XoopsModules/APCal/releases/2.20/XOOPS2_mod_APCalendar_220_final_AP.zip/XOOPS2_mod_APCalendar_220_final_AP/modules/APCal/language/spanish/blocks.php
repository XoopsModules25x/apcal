<?php

if( defined( 'FOR_XOOPS_LANG_CHECKER' ) || ! defined( '_MB_APCAL_BL_LOADED' ) ) {



// Appended by Xoops Language Checker -GIJOE- in 2005-04-22 12:02:00
define('_MB_APCAL_MAXGIFSADAY','Puntos m&aacute;�imos por d��');
define('_MB_APCAL_JUSTONCEADAYAPLUGIN','Mostrar solamente un punto por d�� o por plugin');
define('_MB_APCAL_PLUGINS','Plugins Activos');
define('_MB_APCAL_PLUGINS_DESC','Lista de plugins separados por, (comas)');
define('_MB_APCAL_PLUGINS_VALID','Plugins V&aacute;&Iacute;idos');

// Appended by Xoops Language Checker -GIJOE- in 2005-01-08 04:36:48
define('_MB_APCAL_MAXITEMS','Mostrar');
define('_MB_APCAL_CATSEL','Categor��');
define('_MB_APCAL_CATSELSUB','Mostrar tambien subcategor��s');
define('_MB_APCAL_UNTILDAYS','Durante %s los d��s (0 implica siempre)');

define( '_MB_APCAL_BL_LOADED' , 1 ) ;

// Xoops Mexican & Spanish Support (http://www.neoideas.net/xoops/)
// $Id: blocks.php, v 0.5 2003/11/07 20:00:09$
//%%%%%%	Admin Module Name  APCal 	%%%%%
// for monthly calendar block
define('_MB_APCAL_PREV_MONTH','Anterior');
define('_MB_APCAL_NEXT_MONTH','Siguiente');
define('_MB_APCAL_YEAR','');
define('_MB_APCAL_MONTH','');
define('_MB_APCAL_JUMP','Ir');

// for after the day's events block
// %s means the indicated day
define('_MB_APCAL_EVENTS_AFTER','Eventos despuñ� %s');

// for the day's events block
// %s means the indicated day
define('_MB_APCAL_EVENTS_THEDAY','Eventos en %s');



// Appended by Xoops Language Checker -GIJOE- in 2004-01-14 18:31:00
define('_MB_APCAL_MAXNEWITEMS','Mostrar');

}

?>