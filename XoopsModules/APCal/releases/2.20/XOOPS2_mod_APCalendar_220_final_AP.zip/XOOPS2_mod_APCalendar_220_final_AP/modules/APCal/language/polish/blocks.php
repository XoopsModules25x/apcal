<?php

if( defined( 'FOR_XOOPS_LANG_CHECKER' ) || ! defined( '_MB_APCAL_BL_LOADED' ) ) {

define( '_MB_APCAL_BL_LOADED'  , 1 ) ;

// for monthly calendar block
define('_MB_APCAL_PREV_MONTH'     , 'Poprzedni');
define('_MB_APCAL_NEXT_MONTH'     , 'Nast�pny');
define('_MB_APCAL_YEAR'           , '');
define('_MB_APCAL_MONTH'          , '');
define('_MB_APCAL_JUMP'           , 'Id�');

// for after the day's events block
// %s means the indicated day
define('_MB_APCAL_EVENTS_AFTER'   , 'Wydarzenia po %s');

// for the day's events block
// %s means the indicated day
define('_MB_APCAL_EVENTS_THEDAY'  , 'Wydarzenia w %s');


define("_MB_APCAL_MAXITEMS"       , "Wy�wietl");
define("_MB_APCAL_CATSEL"         , "Kategoria");
define("_MB_APCAL_CATSELSUB"      , "Wy�wietl podkategorie");
define("_MB_APCAL_UNTILDAYS"      , "Do %s dni najwi�cej (0 - niesko�czono��)");

define("_MB_APCAL_MAXGIFSADAY"    , "Maksymalna liczba  wydarze� na dzie�");
define("_MB_APCAL_JUSTONCEADAYAPLUGIN", "Wy�wietl tylko 1 wydarzenie na dzie� i na plugin");

}

?>