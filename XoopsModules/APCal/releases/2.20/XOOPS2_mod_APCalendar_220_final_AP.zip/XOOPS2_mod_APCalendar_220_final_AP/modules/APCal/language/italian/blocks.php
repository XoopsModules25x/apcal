<?php

if( defined( 'FOR_XOOPS_LANG_CHECKER' ) || ! defined( '_MB_APCAL_BL_LOADED' ) ) {



// Appended by Xoops Language Checker -GIJOE- in 2005-04-22 12:02:02
define('_MB_APCAL_MAXGIFSADAY','Max dotgifs per a day');
define('_MB_APCAL_JUSTONCEADAYAPLUGIN','Display just 1 gif per a day and per a plugin');
define('_MB_APCAL_PLUGINS','Active Plugins');
define('_MB_APCAL_PLUGINS_DESC','list the plugin\'s name separated with , (comma)');
define('_MB_APCAL_PLUGINS_VALID','Valid Plugins');

// Appended by Xoops Language Checker -GIJOE- in 2005-01-08 04:36:50
define('_MB_APCAL_MAXITEMS','Mostra');
define('_MB_APCAL_CATSEL','Categoria');
define('_MB_APCAL_CATSELSUB','Mostra anche le sottocategorie');
define('_MB_APCAL_UNTILDAYS','Fino a massimo %s giorni (0 significa in eterno)');

define( '_MB_APCAL_BL_LOADED' , 1 ) ;

// for monthly calendar block
define('_MB_APCAL_PREV_MONTH','Prec.');
define('_MB_APCAL_NEXT_MONTH','Succ.');
define('_MB_APCAL_YEAR','Anno');
define('_MB_APCAL_MONTH','Mese');
define('_MB_APCAL_JUMP','Vai');

// for after the day's events block
// %s means the indicated day
define('_MB_APCAL_EVENTS_AFTER','Eventi dopo il %s');

// for the day's events block
// %s means the indicated day
define('_MB_APCAL_EVENTS_THEDAY','Eventi il %s');


// for new events block
define("_MB_APCAL_MAXNEWITEMS","Mostra");

}

?>
