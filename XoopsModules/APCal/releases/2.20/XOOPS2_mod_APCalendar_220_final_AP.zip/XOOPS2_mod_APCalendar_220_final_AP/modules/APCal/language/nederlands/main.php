<?php

if( defined( 'FOR_XOOPS_LANG_CHECKER' ) || ! defined( 'APCAL_MB_APCALLOADED' ) ) {

define( 'APCAL_MB_APCALLOADED' , 1 ) ;

// index.php
define('_MB_APCAL_ERR_NOPERMTOUPDATE',"You have no permission to change events");
define('_APCAL_APURL', 'http://xoops.antiquespromotion.ca');
define('_APCAL_APURL2', 'http://www.antiquespromotion.ca');
define('_AM_APCAL_COPYRIGHT' , '<a href="http://xoops.antiquespromotion.ca" title="Calendar for Xoops" target="_blank">APCal</a> by <a href="http://www.antiquespromotion.ca" title="Antiques Promotion Canada" target="_blank">AP</a>');
define('_MB_APCAL_ERR_NOPERMTOINSERT',"You have no permission to create events");
define('_MB_APCAL_ERR_NOPERMTODELETE',"You have no permission to delete events");


// Appended by Xoops Language Checker -GIJOE- in 2004-01-14 18:31:01
define('_MB_APCAL_ALT_PRINTTHISEVENT','Print this event');
define('_MB_APCAL_COMESFROM','This event comes from %s');
define('_MB_APCAL_PARMALINK','The URL of this event');

}

?>