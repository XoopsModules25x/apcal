<?php

if( defined( 'FOR_XOOPS_LANG_CHECKER' ) || ! defined( 'APCAL_MB_APCALLOADED' ) ) {

define( 'APCAL_MB_APCALLOADED' , 1 ) ;

// index.php
define('_MB_APCAL_ERR_NOPERMTOUPDATE',"Ni har inte r��tighet att modifiera h��delser");
define('_APCAL_APURL', 'http://xoops.antiquespromotion.ca');
define('_APCAL_APURL2', 'http://www.antiquespromotion.ca');
define('_AM_APCAL_COPYRIGHT' , '<a href="http://xoops.antiquespromotion.ca" title="Calendar for Xoops" target="_blank">APCal</a> by <a href="http://www.antiquespromotion.ca" title="Antiques Promotion Canada" target="_blank">AP</a>');
define('_MB_APCAL_ERR_NOPERMTOINSERT',"Ni har inte r��tighet att skapa h��delser");
define('_MB_APCAL_ERR_NOPERMTODELETE',"Ni har inte r��tighet att radera h��delser");


// Appended by Xoops Language Checker -GIJOE- in 2004-01-14 18:31:01
define('_MB_APCAL_ALT_PRINTTHISEVENT','Skriv ut denna h��delse');
define('_MB_APCAL_COMESFROM','Denna h��delse kommer fr�� %s');
define('_MB_APCAL_PARMALINK','L��ken till denna h��delse');

}

?>