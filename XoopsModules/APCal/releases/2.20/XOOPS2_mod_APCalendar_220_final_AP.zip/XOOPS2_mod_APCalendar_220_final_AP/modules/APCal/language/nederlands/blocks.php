<?php

if( defined( 'FOR_XOOPS_LANG_CHECKER' ) || ! defined( '_MB_APCAL_BL_LOADED' ) ) {



// Appended by Xoops Language Checker -GIJOE- in 2005-04-22 12:02:01
define('_MB_APCAL_MAXGIFSADAY','Max dotgifs per a day');
define('_MB_APCAL_JUSTONCEADAYAPLUGIN','Display just 1 gif per a day and per a plugin');
define('_MB_APCAL_PLUGINS','Active Plugins');
define('_MB_APCAL_PLUGINS_DESC','list the plugin\'s name separated with , (comma)');
define('_MB_APCAL_PLUGINS_VALID','Valid Plugins');

// Appended by Xoops Language Checker -GIJOE- in 2005-01-08 04:36:50
define('_MB_APCAL_MAXITEMS','Display');
define('_MB_APCAL_CATSEL','Category');
define('_MB_APCAL_CATSELSUB','Also displays subcategories');
define('_MB_APCAL_UNTILDAYS','Until %s days at most (0 means eternal)');

define( '_MB_APCAL_BL_LOADED' , 1 ) ;

// for monthly calendar block
define('_MB_APCAL_PREV_MONTH','Vorige');
define('_MB_APCAL_NEXT_MONTH','Volgende');
define('_MB_APCAL_YEAR','Jaar');
define('_MB_APCAL_MONTH','Maand');
define('_MB_APCAL_JUMP','Ga naar');

// for after the day's events block
// %s means the indicated day
define('_MB_APCAL_EVENTS_AFTER','Activiteiten na %s');

// for the day's events block
// %s means the indicated day
define('_MB_APCAL_EVENTS_THEDAY','Activiteiten op %s');



// Appended by Xoops Language Checker -GIJOE- in 2004-01-14 18:31:01
define('_MB_APCAL_MAXNEWITEMS','Display');

}

?>