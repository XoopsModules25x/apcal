<?php

if( defined( 'FOR_XOOPS_LANG_CHECKER' ) || ! defined( 'APCAL_MB_APCALLOADED' ) ) {

define( 'APCAL_MB_APCALLOADED' , 1 ) ;
 //* Brazilian Portuguese Translation by Marcelo Yuji Himoro <www.yuji.eu.org> *//
// index.php
define('_MB_APCAL_ERR_NOPERMTOUPDATE',"Voc� n�� tem autoriza��o para alterar eventos.");
define('_APCAL_APURL', 'http://xoops.antiquespromotion.ca');
define('_APCAL_APURL2', 'http://www.antiquespromotion.ca');
define('_AM_APCAL_COPYRIGHT' , '<a href="http://xoops.antiquespromotion.ca" title="Calendar for Xoops" target="_blank">APCal</a> by <a href="http://www.antiquespromotion.ca" title="Antiques Promotion Canada" target="_blank">AP</a>');
define('_MB_APCAL_ERR_NOPERMTOINSERT',"Voc� n�� tem autoriza��o para criar eventos.");
define('_MB_APCAL_ERR_NOPERMTODELETE',"Voc� n�� tem autoriza��o para apagar eventos.");
define('_MB_APCAL_ALT_PRINTTHISEVENT',"Imprimir este evento");

// print.php
define('_MB_APCAL_COMESFROM',"Evento vindo de %s");
define('_MB_APCAL_PARMALINK',"URL deste evento");


}

?>